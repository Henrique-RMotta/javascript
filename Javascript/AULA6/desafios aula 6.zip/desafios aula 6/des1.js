let numero1 =  parseFloat(prompt(`digite o primeriro valor `));
let numero2 = parseFloat(prompt(`digite o segundo valor `));
let soma = numero1 + numero2;
alert(soma);