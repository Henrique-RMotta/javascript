//exercicio 5 - operadores numéricos
let a = 10;
let b = 20;
let c = 15;

console.log(a<c);//true
console.log(c>b && a>c);//false
console.log (b<a || b>c);//true
console.log(a<c<b);//true