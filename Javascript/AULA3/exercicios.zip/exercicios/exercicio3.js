// exercicio 3  - operador nao
let z = true; 

console.log(!z);//false
console.log(!false);//true
console.log(!(z&&false));//true
console.log(!z || false ); // false