function botao1(){
    alert("você apertou o botão 1")
}

function botao2(){
    alert("você apertou botão 2")
}

function botao3(){
    alert("você apertou botão 3")
}